from django.shortcuts import render,redirect
# from app1.models import Category,Userregister,Product,Order
from django.http import HttpResponse
from app1.models import *
# Create your views here.

def index(request):
    data=Category.objects.all()
    
    return render(request,'index.html',{'cat':data})


def allproduct(request):
    data=Product.objects.all()
    return render(request,'product.html',{'cat':data})



def product_filter(request,id):
    data=Product.objects.filter(categoryname=id)
    return render(request,'product.html',{'cat':data})

def product_get(request,id):
    data=Product.objects.get(id=id)
    return render(request,'product_details.html',{'cat':data})

def Register(request):
    if request.method=="POST":
        name1=request.POST['name']
        email1=request.POST['email']
        address1=request.POST['address']
        number1=request.POST['number']
        pass1=request.POST['password']
        userdata=Userregister(name=name1,email=email1,number=number1,address=address1,password=pass1)
        if len(Userregister.objects.filter(email=email1))==0:
            userdata.save()
            return redirect('login1')
        else:
            return render(request,'register.html',{'m':"User Already Exist"})
    return render(request,'register.html')


def login(request):
    if request.method=="POST":
        email1=request.POST['email']
        password1=request.POST['password']
        try:
            user=Userregister.objects.get(email=email1,password=password1)
            if user:
                request.session['id']=user.pk
                request.session['email']=user.email
                return redirect('home')
            else:
                return render(request,'login.html',{'m':'Invalid password'})
        except:
            return render(request,'login.html',{'m':'Invalid Data Enter'})
    return render(request,'login.html')

def logout(request):
    if "email" in request.session:
        del request.session['id']
        del request.session['email']
        return redirect('login1')
    else:
        return redirect('login1')
    

def buynow(request):
    if "email" in request.session:
        if request.POST:
            data=Order()
            data.userid=request.session['id']
            data.productid=request.POST['productid']
            data.quantity=request.POST['quantity']
            productdata=Product.objects.get(id=request.POST['productid'])
            data.paymentamt=int(data.quantity)*int(productdata.price)
            data.paymentmethod="Razorpay"
            data.transactionid="123456789"
            data.save()
            return HttpResponse("<h1>Order Done </h1>")

    else:
        return redirect('login1') 